<div class="container mx-auto max-w-screen-xl">
    Mua hàng thành công chúng tôi sẽ liên hệ sớm với bạn
</div>