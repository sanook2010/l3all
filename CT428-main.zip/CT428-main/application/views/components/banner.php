<div class="">
    <div class="swiper-container swipperBanner">
        <div class="swiper-wrapper">
            <div class="swiper-slide">
                <img src="/public/images/banners/banner3.png" alt="">
            </div>
            
        </div>
    </div>
</div>