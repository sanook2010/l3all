<?php

namespace application\models;

use application\core\Model;

class Category extends Model
{

    protected $table = "loaihanghoa";
    protected $primary_key = "MaLoaiHang";
}
