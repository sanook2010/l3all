<?php

namespace application\models;

use application\core\Model;

class Customer extends Model
{

    protected $table = "khachhang";
    protected $primary_key = "MSKH";
}
