<?php

namespace application\models;

use application\core\Model;

class Order_detail extends Model
{

    protected $table = "chitietdathang";
    protected $primary_key = "SoDonDH";
}
