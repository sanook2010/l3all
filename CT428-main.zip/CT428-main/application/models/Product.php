<?php

namespace application\models;

use application\core\Model;

class Product extends Model
{

    protected $table = 'hanghoa';
    protected $primary_key = "MSHH";
}
