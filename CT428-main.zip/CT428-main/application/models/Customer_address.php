<?php

namespace application\models;

use application\core\Model;

class Customer_address extends Model
{

    protected $table = "diachikh";
    protected $primary_key = "MaDC";
}
