<?php

return [
	'all' => [
		'index', 'store'
	],
	'authorize' => [
		//
	],
	'guest' => [
		//
	],
	'admin' => [
		//
	],
];
