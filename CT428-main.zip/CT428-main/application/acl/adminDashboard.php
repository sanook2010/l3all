<?php

return [
    'all' => [
        //
    ],
    'authorize' => [
        //
    ],
    'guest' => [],
    'admin' => [
        //
        'index'
    ],
];
