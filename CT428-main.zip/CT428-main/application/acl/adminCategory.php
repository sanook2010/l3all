<?php

return [
    'all' => [
        //
    ],
    'authorize' => [
        //
    ],
    'guest' => [],
    'admin' => [
        //
        'index',
        'create',
        'store',
        'update',
        'edit',
        'destroy'
    ],
];
