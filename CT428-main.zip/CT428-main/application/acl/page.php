<?php

return [
	'all' => [
		'about', 'order', 'contact'
	],
	'authorize' => [
		//
	],
	'guest' => [
		//
	],
	'admin' => [
		//
	],
];
