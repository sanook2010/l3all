<?php

return [
	'all' => [
		'index', 'show',
	],
	'authorize' => [
		//
	],
	'guest' => [
		//
	],
	'admin' => [
		//
	],
];
