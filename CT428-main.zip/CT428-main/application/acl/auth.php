<?php

return [
	'all' => [
		//
	],
	'authorize' => [
		//
	],
	'guest' => [
		'loginIndex',
		'login',
	],
	'admin' => [
		//
	],
];
