<?php

return [
	'host' => '127.0.0.1',
	'name' => 'CT428',
	'user' => 'root',
	'password' => '',
];
